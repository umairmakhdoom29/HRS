# Breast Cancer Health Recommender System (Prototype)

This is a starter template for building a Health Recommender System (HRS) tailored to breast cancer diagnosis support. It works even without a dataset using:
- Synthetic/mock model outputs
- Rule-based logic
- Flask backend
- Gradio UI

### Usage:
1. Run the Flask server:
```bash
cd backend && python app.py
```
2. In a new terminal, run the Gradio UI:
```bash
cd frontend && python gradio_ui.py
```

### Future Steps:
- Replace fake model with ML models trained on real datasets
- Connect with hospital/clinical data
- Add database layer (MongoDB / PostgreSQL)