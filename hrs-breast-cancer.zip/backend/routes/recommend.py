from mock_model.predict import fake_model
from utils.rules import rule_based_engine

def get_recommendation(data):
    model_output = fake_model(data)
    rule_output = rule_based_engine(data)
    
    return {
        "model_prediction": model_output,
        "rule_based_advice": rule_output,
        "final_decision": model_output or rule_output
    }