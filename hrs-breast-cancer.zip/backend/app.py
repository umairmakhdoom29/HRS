from flask import Flask, request, jsonify
from routes.recommend import get_recommendation

app = Flask(__name__)

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.get_json()
    result = get_recommendation(data)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)