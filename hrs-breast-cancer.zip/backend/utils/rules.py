def rule_based_engine(data):
    symptoms = data.get("symptoms", [])
    if "lump" in symptoms or "pain" in symptoms:
        return "Recommend immediate mammogram"
    return "Annual screening recommended"