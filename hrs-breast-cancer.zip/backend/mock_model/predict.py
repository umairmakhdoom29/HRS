def fake_model(data):
    age = data.get("age", 0)
    if age > 50:
        return "Malignant (Confidence: 72%)"
    return "Benign (Confidence: 85%)"