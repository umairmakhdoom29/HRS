import gradio as gr
import requests

def get_recommendation_ui(age, symptoms):
    response = requests.post("http://127.0.0.1:5000/recommend", json={
        "age": int(age),
        "symptoms": symptoms.split(",")
    })
    return response.json()

iface = gr.Interface(
    fn=get_recommendation_ui,
    inputs=[
        gr.Number(label="Age"),
        gr.Textbox(label="Symptoms (comma-separated)")
    ],
    outputs="json",
    title="Breast Cancer Health Recommender System"
)

iface.launch()